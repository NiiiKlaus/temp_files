# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

path = input('Please enter the path to your file: ')
while path == '':
    print('You have not entered path!')
    path = input('Please enter the path to your file: ')
print('Start analysing...')
    
def handle_line(raw_line):
    indent = -1
    for i in range(len(raw_line)):
        if line[i] == r'#':
            indent = indent + 1  
        else:
            break
    return (raw_line, indent)

with open(path, 'r') as f:
    headline_list = []
    while True:
        line = f.readline()
        if line == '':
            break
        if line[0] == r'`':
            while True:
                line = f.readline()
                if line[0] != r'`':
                    continue
                else:
                    break
        else:
            result = handle_line(line)
            if result[1] == -1:
                pass
            else:
                headline_list.append(result)
    print('Analysing finished!')
    for headline in headline_list:
        raw_line = headline[0]
        indent = headline[1] * '  '
        temp = raw_line.strip('\n')[headline[1]+2:].lower()
        raw_result = ''
        for i in range(len(temp)):
            if temp[i] == ' ':
                raw_result = raw_result + r'-'
            code = ord(temp[i])
            if not ((code >= 32 and code <= 47) or (code >= 58 and code <= 64) or (code >= 91 and code <= 96) or (code >= 123 and code <= 126)):
                raw_result = raw_result + temp[i]
        result = '{}- [{}](#{})'.format(indent, raw_line.strip()[headline[1]+2:], raw_result)
        print(result)

    
            
            
