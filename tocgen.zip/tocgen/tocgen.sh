paths=(
'/home/niklaus/github/niiiklaus/Get-my-Arch-Linux/system-installation.md'
'/home/niklaus/github/niiiklaus/Get-my-Arch-Linux/system-installation-trouble-shooting.md'
'/home/niklaus/github/niiiklaus/Get-my-Arch-Linux/initial-configuration.md'
'/home/niklaus/github/niiiklaus/Get-my-Arch-Linux/initial-configuration-trouble-shooting.md'
'/home/niklaus/github/niiiklaus/Get-my-Arch-Linux/software.md'
'/home/niklaus/github/niiiklaus/Get-my-Arch-Linux/software-trouble-shooting.md'
'/home/niklaus/github/niiiklaus/Get-my-Arch-Linux/prettification.md'
'/home/niklaus/github/niiiklaus/Get-my-Arch-Linux/prettification-trouble-shooting.md'
)
script='/home/niklaus/github/niiiklaus/tocgen/tocgen-modified.py'

if [ $1 ]
then
    attr=$1
else
    attr=''
fi
if [ $2 ]
then
    conv=$1
else
    conv=''
fi

main() {
    for path in ${paths[@]}
    do
        python $script $path $attr $conv
    done
}

main
