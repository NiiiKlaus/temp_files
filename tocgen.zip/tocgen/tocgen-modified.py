# -*- coding: utf-8 -*-
import sys
import os

try:
    path = sys.argv[1]
    filename = os.path.split(path)[1]
except BaseException:
    sys.exit()
try:
    attr = sys.argv[2]
except BaseException:
    attr = ''
try:
    conv = sys.argv[3]
except BaseException:
    conv = ''


def handle_line(raw_line):
    indent = -1
    for i in range(len(raw_line)):
        if line[i] == r'#':
            indent = indent + 1
        else:
            break
    return (raw_line, indent)

def gen_toc(headline_list, attr, conv):
    for headline in headline_list:
        raw_line = headline[0]
        indent = headline[1] * '  '
        temp = raw_line.strip('\n')[headline[1] + 2:].lower()
        raw_result = ''
        for i in range(len(temp)):
            if temp[i] == ' ':
                raw_result = raw_result + r'-'
            code = ord(temp[i])
            if not (
                (code >= 32 and code <= 47) or (
                    code >= 58 and code <= 64) or (
                    code >= 91 and code <= 96) or (
                    code >= 123 and code <= 126)):
                raw_result = raw_result + temp[i]
        if attr == 'main':
            result = '{}- [{}]({}/#{})'.format(indent,
                                               raw_line.strip()[headline[1] + 2:],
                                               filename,
                                               raw_result)
        elif attr == 'sep':
            if headline_list.index(headline) == 0 and conv == 't':
                result = r'- [返回README.md](README.md)'
            else:
                result = '{}- [{}](#{})'.format(indent,
                                                raw_line.strip()[headline[1] + 2:], raw_result)
        else:
            result = '{}- [{}](#{})'.format(indent,
                                            raw_line.strip()[headline[1] + 2:], raw_result)
        print(result)
        
with open(path, 'r') as f:
    headline_list = []
    while True:
        line = f.readline()
        if line == '':
            break
        if line[0] == r'`':
            while True:
                line = f.readline()
                if line[0] != r'`':
                    continue
                else:
                    break
        else:
            result = handle_line(line)
            if result[1] == -1:
                pass
            else:
                headline_list.append(result)
    gen_toc(headline_list, attr, conv)